# Architettura (fase 0)

```
UTENTE (CLI / chat React / API)
        |
   ATLAS Core (POST /ask)
        |  1. classifica (question | new_info | action_request | analysis)
        |  2. recupera memorie (retrieval ibrido)
        |  3. risponde citando, oppure "Non lo so"
        v
 Memory Engine ---- Model Router (embed/generate)
        |                |-- LocalHash (offline, default)
        |                |-- Ollama (opzionale)
        v
 PostgreSQL 16 + pgvector
 (users, sources, projects, events append-only, memories, action_logs)
```

## Recupero ibrido

Punteggio finale = `w_semantic*semantico + w_text*testuale + w_recency*recenza + w_confidence*confidenza`

- **semantico**: `1 - cosine_distance` (pgvector `<=>`)
- **testuale**: `ts_rank` di PostgreSQL (config `simple`), normalizzato con
  `min(1, rank*4)`: su frasi brevi il rank grezzo è piccolo (tipicamente
  < 0.25); il fattore 4 porta una corrispondenza piena vicino a 1. Costante
  empirica da calibrare sul benchmark (vedi `scripts/benchmark.py`).
- **recenza**: decadimento esponenziale con emivita configurabile (default 30g)
- **confidenza**: valore 0..1 memorizzato

La **rilevanza** (`w_semantic + w_text`, senza prior di qualità) guida il gate
«Non lo so»: se nessun risultato supera `ATLAS_ASK_MIN_RELEVANCE` (default
0.12), il sistema risponde «Non lo so». Recenza e confidenza riordinano ma non
possono mai rendere "pertinente" una memoria che non c'entra.

I pesi sono configurabili via env (`ATLAS_W_*`).

## Sostituzione, non sovrascrittura

Quando un'informazione cambia si crea una nuova memoria e la vecchia riceve
`superseded_by`. Le memorie sostituite escono dal recupero normale ma restano
nel database: sono la base della Time Machine (fase 5).

## Eventi append-only

Nessun endpoint di update/delete su `/events`. La cancellazione esiste solo
come diritto all'oblio completo (`DELETE /me`).

## Model Router

`embed()` e `generate()` con provider intercambiabili:

| Provider | Uso | Costo | Note |
|---|---|---|---|
| `local` / `extractive` | default | 0 | deterministico, offline, qualità lessicale |
| `ollama` | opzionale | 0 (locale) | richiede Ollama con i modelli scaricati |

Se Ollama non risponde, il router fa fallback sui provider locali e lo
registra in `action_logs` (modello, durata, token stimati, costo).

## Isolamento utenti

Ogni query filtra per `user_id`. `tests/test_isolation.py` verifica che
l'utente B non possa leggere, cercare, citare, sostituire o esportare dati
dell'utente A.

## Fase 1

- **Contraddizioni** (`app/services/contradictions.py`): euristica conservativa.
  Due memorie attive sono possibili contraddizioni se condividono >= 2 parole
  di contenuto (soggetto) ma assegnano valori disgiunti nella stessa categoria
  (numeri, giorni della settimana, mesi). Le proposte compaiono in
  `possible_contradictions` alla scrittura e nella vista
  `GET /memories/contradictions`. La risoluzione è sempre dell'utente, via
  sostituzione (`supersedes`).
- **Knowledge Graph** (`app/services/entities.py`, router `/graph/*`): tabelle
  `entities` e `relationships` con stato `pending|confirmed|rejected`.
  L'estrazione da testo è rule-based (nomi capitalizzati, pochi pattern
  relazionali espliciti) e crea solo proposte: niente scrittura diretta nel
  grafo. Conferma/rifiuto via API. `GET /graph/project-links` elenca i
  collegamenti confermati che coinvolgono progetti.
- **Conversazioni** (`conversations`, `messages`): ogni `/ask` salva il turno
  utente e la risposta; il client può continuare una conversazione passando
  `conversation_id`.
- **Orchestratore** (`app/services/orchestrator.py`): punto unico del flusso
  /ask (classifica -> memoria/stato progetto/rifiuto azione -> persistenza
  turno). Gli agenti di fase 2 si agganceranno qui.
- **Stato progetto**: classificatore riconosce "a che punto sono con ...";
  la risposta elenca solo eventi e date realmente registrati.

## Fase 2

- **Agenti** (`app/agents/`): Researcher (recupero memorie via Retrieval ibrido),
  Planner (scomposizione dell'obiettivo in attivita ordinate), Critic
  (verifica appoggio delle attivita sui fatti; segnala empty_plan e
  unsourced_claim). Messaggi Pydantic in `app/agents/schemas.py`.
- **Limiti**: MAX_STEPS=3, TIMEOUT_S=20, costo sempre 0 (tutto locale).
- **Registro**: tabella `agent_runs` (input/output JSONB, passi, durata, costo,
  esito) esposta via `GET /agents/runs`.
- Pipeline via `POST /agents/run` {"goal": "..."}; il Critic decide
  l'approvazione finale.
